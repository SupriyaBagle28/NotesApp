export class INotes{
    title:string;
    content:string;
}