import { Component, OnInit } from '@angular/core';
import {AngularFireDatabase} from 'angularfire2/database';
import {NotesService} from '../service/notes.service'; 
import {Router} from '@angular/router'

@Component({
  selector: 'app-new-note',
  templateUrl: './new-note.component.html',
  styleUrls: ['./new-note.component.css']
})
export class NewNoteComponent implements OnInit {

  constructor(private router:Router,
    private db:AngularFireDatabase,
    private noteservice:NotesService) { }

  ngOnInit(): void {
  }

  save(data){
    this.noteservice.addNotes(data);
    console.log(data);
    this.router.navigate(['/home']);
  }

}
