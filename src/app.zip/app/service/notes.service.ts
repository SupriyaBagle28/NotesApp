import { INotes } from './../Files/Notes';
import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { Observable } from 'rxjs';
import { AngularFireAuth } from 'angularfire2/auth';


@Injectable({
  providedIn: 'root'
})

export class NotesService {

  // notes : AngularFireList<INotes[]> = null;
  // userId : string;

  constructor(private db: AngularFireDatabase, private afAuth:AngularFireAuth) { 
    // this.afAuth.authState.subscribe(user=>{
    //   if(user)this.userId=user.uid
    // })
  }

  // getNotes(): AngularFireList<INotes[]> {
  //    if(!this.userId) return;
  //    this.notes= this.db.list(`notes/${this.userId}`);
  //    return this.notes;
  // }

  getNotes(): Observable<any> {
    return this.db.list('/data').valueChanges();
 }

  addNotes(data) {
    return this.db.list('/data').push(data);
  }
}
